using UnityEngine;
using UnityEngine.UIElements;

public class SpinningObstacle : MonoBehaviour
{
    [SerializeField] private float Xangle = 0;
    [SerializeField] private float Yangle = 0;
    [SerializeField] private float Zangle = 0;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // Rotate this object based on the value given for each axis multiplied by time.
        this.transform.Rotate(Xangle * Time.deltaTime, Yangle * Time.deltaTime, Zangle * Time.deltaTime);
    }
}
