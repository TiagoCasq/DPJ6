using UnityEngine;

public class MovingPlatform : MonoBehaviour
{

    [SerializeField] private Transform pointA;
    [SerializeField] private Transform pointB;
    private Transform targetPoint;
    private float waitingTime = 0;
    [SerializeField] private float movingSpeed = 2;
    private float waitTimer;
    private bool isWaiting;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        targetPoint = pointB;
        waitTimer = 0;
        isWaiting = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (isWaiting)
        {
            waitTimer++;

            if (waitTimer >= waitingTime)
            {
                isWaiting = false;
                targetPoint = (targetPoint == pointA) ? pointB : pointA;
            }
        }
        else
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPoint.position, movingSpeed * Time.deltaTime);

            // If the distance between the platform and the targetPoint is under 0.01f then it will indicate that both of them have the same position and set the "IsWaiting" bool to true,
            // making it so the platform can wait a choosen ammount of time before going to the next point
            if (Vector3.Distance(transform.position, targetPoint.position) < 0.01f)
            {
                transform.position = targetPoint.position;
                isWaiting = true;
                waitTimer = 0f;
            }
        }
    }


}