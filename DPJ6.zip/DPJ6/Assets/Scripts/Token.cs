using System.Threading;
using Unity.VisualScripting;
using UnityEngine;
using static UnityEngine.Rendering.DebugUI;
[RequireComponent(typeof(Collider))]
public class Token : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    
    public int Value;

    public AudioClip pickupSfx;

    
    private AudioSource audioSource;

    
    void Start()
    {

    }

    private void Awake()
    {
        GetComponent<Collider>().isTrigger = true;
        audioSource = gameObject.AddComponent<AudioSource>();
        if (GetComponent<Collider>().isTrigger == false)
        {
            audioSource.enabled = false;
        }
    }

    void OnTriggerEnter(Collider other)
    {

        
        if (other.tag != "Player")
        {
            return;
        } else if (UIManager.Instance != null)
        {
            GetComponent<Collider>().enabled = false;
            GetComponent<Renderer>().enabled = false;
            UIManager.Instance.AddScore(1);

            if (pickupSfx != null)
            {
                print("Audio play");
                audioSource.generator = pickupSfx;
                audioSource.Play();

            }
        }

        Destroy(gameObject, 4f);

    }
    // Update is called once per frame
    void Update()
    {
        
    }

    
}
