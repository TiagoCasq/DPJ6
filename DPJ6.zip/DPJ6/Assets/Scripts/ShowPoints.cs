using System.Runtime.CompilerServices;
using UnityEngine;

public class ShowPoints : MonoBehaviour
{
    // On detecting a collision with an object, it checks if the object contains the "Player" tag.
    // If the Player is detected, the script gets the PlayerController and accesses and shows its point variable value. 
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag == "Player")
        {
            int CurrentPoints = UIManager.Instance.score;

            if (CurrentPoints == 29)
            {
                Debug.Log("Level Finished! Your score is: " + CurrentPoints);
            }
            else if (CurrentPoints == 30)
            {
                Debug.Log("how did you find it.");
            }
            else
            {
                Debug.Log("You need at least 29 points to finish the level! ");
            }


            

        }
    }
}
