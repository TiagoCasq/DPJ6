using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI livesText;

    public int startLives = 3;
    public int score = 0;

    private int lives;

    private void Awake()
    {
        if(Instance != null)
        {
            Destroy(gameObject);
        }

        Instance = this;

        lives= startLives;

        UpdateScoreUI();
        UpdateLivesUI();

    }

    public void AddScore(int amount)
    {
        score += amount;
        UpdateScoreUI();
    }

    void UpdateScoreUI()
    {
        scoreText.text = "Score: " + score;
    }

    void SetLives(int newLives)
    {
        lives = newLives;
        UpdateLivesUI();
    }

    void UpdateLivesUI()
    {
        livesText.text = "Current Lives: " + lives;
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
     
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
