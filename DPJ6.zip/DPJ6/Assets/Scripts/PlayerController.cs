using System.Runtime.CompilerServices;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    public float moveSpeed;
    public float maxSpeed;
    public float jumpForce;
    public float groundCheckRadius;
    public float horizontalInput;
    public float verticalInput;

    public bool isGrounded;

    public Transform groundCheck;

    public LayerMask groundLayer;

    public Rigidbody rb;
    

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.freezeRotation = true;
        
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        verticalInput = Input.GetAxisRaw("Vertical");
        horizontalInput =  Input.GetAxisRaw("Horizontal")   ;

        if (Input.GetButtonDown("Jump"))
        {
            if (isGrounded)
            {
                Jump();
            }
        }
            
            
            
    }

    void FixedUpdate()
    {
        isGrounded = Physics.CheckSphere(groundCheck.position, groundCheckRadius, groundLayer);
        Vector3 velocity = rb.linearVelocity;
        float targetVelX = horizontalInput * moveSpeed;
        float newVelX = Mathf.MoveTowards(velocity.x, targetVelX, 50f * Time.fixedDeltaTime);
        float targetVelZ = verticalInput * moveSpeed;
        float newVelZ = Mathf.MoveTowards(velocity.z, targetVelZ, 50f * Time.fixedDeltaTime);
        rb.linearVelocity = new Vector3(Mathf.Clamp(newVelX, -maxSpeed, maxSpeed), velocity.y, Mathf.Clamp(newVelZ, -maxSpeed, maxSpeed));
    }

    void Jump()
    {
        Vector3 force = new Vector3(0,jumpForce,0);
        Vector3 jumpVel = rb.linearVelocity;
        jumpVel.y = 0f;


         rb.AddForce(force, ForceMode.VelocityChange);

    }

        
}
